import java.sql.Connection;
import java.util.Scanner;

import com.test.jdbc.DBConnection;
import com.test.jdbc.UseProperitesManageConfig;
import com.test.dao.StudentDAO;
import com.test.model.*;
//import com.test.model.Menus;
//import com.test.model.Table;
//import com.test.model.vip;
//import com.test.model.Employee;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        System.out.println("----------------------------------------------------------");
        System.out.println("-----------------欢迎使用网上书店-------------------------");
//        System.out.println("顾客点餐请输入1");
        System.out.println("管理人员请输入0");
//        System.out.println("----------------------------------------------------------");


//        System.out.print("请输入您的选择：");
        Scanner sc = new Scanner(System.in);
        int choice1 = sc.nextInt();
        if (choice1 == 0) {
//            System.out.println("欢迎进入顾客点餐界面");
            UseProperitesManageConfig Con_Sql = new UseProperitesManageConfig();
//            Con_Sql.Sql_Link(null,null,1);
            Con_Sql.Sql_Link(null, null, 1);
//            i = Con_Sql.Sql_Link("root","141510",1);


            while (true) {
                System.out.println("你可以查看下表内容：");
                System.out.println("1-出版社管理");
                System.out.println("2-书籍管理");
                System.out.println("3-运输公司管理");
//                System.out.println("1-查看出版社信息");
//                System.out.println("2-查看书籍");
//                System.out.println("3-查看运输公司");
//                System.out.println("4-增加书籍信息");
//                System.out.println("5.增加出版社信息");
//                System.out.println("6.增加配送公司信息");
//                System.out.println("7.删除配送公司信息");
//                System.out.println("8.删除书籍信息");
//                System.out.println("9.删除出版社信息");
//                System.out.println("10.修改书籍信息");
//                System.out.println("11.修改出版社信息");
//                System.out.println("12.修改运输公司信息");
                System.out.println("键入其他，退出");
                int choice = sc.nextInt();
                if (choice == 1) {
                    System.out.println("1-查看出版社信息");
                    System.out.println("2.增加出版社信息");
                    System.out.println("3.删除出版社信息");
                    System.out.println("4.修改出版社信息");
                    System.out.print("请输入您的选择：");
                    int choice2 = sc.nextInt();
                    switch (choice2) {
                        case 1:
                            StudentDAO s1 = new StudentDAO();
                            List<Press> list1 = s1.getAll_press();
                            for (Press stus1 : list1)
                                System.out.println("出版社名：" + stus1.getPressTitle() + "  出版社地址：" + stus1.getAddress() + "  出版社负责人：" + stus1.getContactPerson() + "  联系电话：" + stus1.getTelephone() + "  邮箱地址：" + stus1.getEmail());
                            System.out.println();
                            break;
                        case 2:
                            StudentDAO s5 = new StudentDAO();
                            System.out.println("输入出版社编号：");
                            int pressID = sc.nextInt();
                            System.out.println("输入出版社名称：");
                            String pressTitle = sc.next();
                            System.out.println("输入出版社地址：");
                            String address = sc.next();
                            System.out.println("输入出版社负责人：");
                            String contactPerson = sc.next();
                            System.out.println("输入出版社联系方式：");
                            String telephone = sc.next();
                            System.out.println("输入出版社邮箱地址：");
                            String email = sc.next();

                            s5.add_press(pressID, pressTitle, address, contactPerson, telephone, email);
                            System.out.println();
                            break;
                        case 3:
                            StudentDAO s9 = new StudentDAO();
                            System.out.println("输入删除的出版社名称：");
                            String pressTitle1 = sc.next();
                            s9.delete_press(pressTitle1);
                            break;
                        case 4:
                            StudentDAO s11 = new StudentDAO();
                            Press press1 = new Press();

                            System.out.println("输入出版社名称：");
                            press1.setPressTitle(sc.next());
                            System.out.println("输入修改后的地址：");
                            press1.setAddress(sc.next());
                            System.out.println("输入修改后的负责人：");
                            press1.setContactPerson(sc.next());
                            System.out.println("输入修改后的联系方式：");
                            press1.setTelephone(sc.next());
                            System.out.println("输入修改后的邮箱地址：");
                            press1.setEmail(sc.next());

                            s11.update_press(press1);
                            System.out.println();
                            break;
                        default:
                            break;
                    }
                } else if (choice == 2) {
                    System.out.println("1-查看书籍信息");
                    System.out.println("2.增加书籍信息");
                    System.out.println("3.删除书籍信息");
                    System.out.println("4.修改书籍信息");
                    System.out.print("请输入您的选择：");
                    int choice2 = sc.nextInt();
                    switch (choice2) {
                        case 1:
                            StudentDAO s2 = new StudentDAO();
                            List<Books> list2 = s2.getAll_books();
                            for (Books stus2 : list2)
                                System.out.println("编号：" + stus2.getBookID() + "书名：" + stus2.getBookTitle() + "价格：" + stus2.getPrice() + "作者：" + stus2.getAuthor());
                            System.out.println();
                            break;
                        case 2:
                            StudentDAO s3 = new StudentDAO();
                            System.out.println("输入书籍编号：");
                            int bookID = sc.nextInt();
                            System.out.println("输入书籍名称：");
                            String bookTitle = sc.next();
                            System.out.println("输入价格：");
                            double price = sc.nextDouble();
                            System.out.println("输入作者：");
                            String author = sc.next();
                            s3.add_books(bookID, bookTitle, price, author);
                            System.out.println();
                            break;
                        case 3:
                            StudentDAO s8 = new StudentDAO();
                            System.out.println("输入删除的书籍名称：");
                            String bookTitle1 = sc.next();
                            s8.delete_books(bookTitle1);
                            break;
                        case 4:
                            StudentDAO s10 = new StudentDAO();
                            Books books1 = new Books();

                            System.out.println("输入书名：");
                            books1.setBookTitle(sc.next());
                            System.out.println("输入修改后的价格：");
                            books1.setPrice(sc.nextDouble());

                            s10.update_books(books1);
                            System.out.println();
                            break;
                    }
                } else if (choice == 3) {
                    System.out.println("1-查看配送公司信息");
                    System.out.println("2.增加配送公司信息");
                    System.out.println("3.删除配送公司信息");
                    System.out.println("4.修改配送公司信息");
                    System.out.print("请输入您的选择：");
                    int choice2 = sc.nextInt();
                    switch (choice2) {
                        case 1:
                            StudentDAO s4 = new StudentDAO();
                            List<Company> list4 = s4.getAll_company();
                            for (Company stus4 : list4)
                                System.out.println("编号：" + stus4.getCompanyID() + "  运输公司名：" + stus4.getCompanyTitle() + "  地址：" + stus4.getAddress() + "  运输公司负责人：" + stus4.getContactPerson() + "  联系方式：" + stus4.getTelephone() + "  邮箱地址：" + stus4.getEmail());
                            System.out.println();
                            break;
                        case 2:
                            StudentDAO s6 = new StudentDAO();
                            System.out.println("输入配送公司编号：");
                            int companyID = sc.nextInt();
                            System.out.println("输入配送公司名称：");
                            String companyTitle = sc.next();
                            System.out.println("输入配送公司地址：");
                            String companyAddress = sc.next();
                            System.out.println("输入配送公司负责人：");
                            String companyContactPerson = sc.next();
                            System.out.println("输入配送公司联系方式：");
                            String companyTelephone = sc.next();
                            System.out.println("输入配送公司邮箱地址：");
                            String companyEmail = sc.next();
                            s6.add_company(companyID, companyTitle, companyAddress, companyContactPerson, companyTelephone, companyEmail);
                            System.out.println();
                            break;
                        case 3:
                            StudentDAO s7 = new StudentDAO();
                            System.out.println("输入删除的公司名称：");
                            String companyTitle1 = sc.next();
                            s7.delete_company(companyTitle1);
                        case 4:
                            StudentDAO s12 = new StudentDAO();
                            Company company1 = new Company();

                            System.out.println("输入运输公司名称：");
                            company1.setCompanyTitle(sc.next());
                            System.out.println("输入修改后的地址：");
                            company1.setAddress(sc.next());
                            System.out.println("输入修改后的负责人：");
                            company1.setContactPerson(sc.next());
                            System.out.println("输入修改后的联系方式：");
                            company1.setTelephone(sc.next());
                            System.out.println("输入修改后的邮箱地址：");
                            company1.setEmail(sc.next());

                            s12.update_company(company1);
                            System.out.println();
                            break;
                    }
                }
//            System.out.print("请输入您的选择：");
//            int choice1 = sc.nextInt();
//            switch (choice1) {
//                case 1:
//                    StudentDAO s1 = new StudentDAO();
//                    List<Press> list1 = s1.getAll_press();
//                    for (Press stus1 : list1)
//                        System.out.println("出版社名：" + stus1.getPressTitle() + "  出版社地址：" + stus1.getAddress() + "  出版社负责人：" + stus1.getContactPerson() + "  联系电话：" + stus1.getTelephone() + "  邮箱地址：" + stus1.getEmail());
//                    System.out.println();
//                    break;
//                case 2:
//                    StudentDAO s2 = new StudentDAO();
//                    List<Books> list2 = s2.getAll_books();
//                    for (Books stus2 : list2)
//                        System.out.println("编号：" + stus2.getBookID() + "书名：" + stus2.getBookTitle() + "价格：" + stus2.getPrice() + "作者：" + stus2.getAuthor());
//                    System.out.println();
//                    break;
//                case 3:
//                    StudentDAO s4 = new StudentDAO();
//                    List<Company> list4 = s4.getAll_company();
//                    for (Company stus4 : list4)
//                        System.out.println("编号：" + stus4.getCompanyID() + "  运输公司名：" + stus4.getCompanyTitle() + "  地址：" + stus4.getAddress() + "  运输公司负责人：" + stus4.getContactPerson() + "  联系方式：" + stus4.getTelephone() + "  邮箱地址：" + stus4.getEmail());
//                    System.out.println();
//                    break;
//                case 4:
//                    StudentDAO s3 = new StudentDAO();
//                    System.out.println("输入书籍编号：");
//                    int bookID = sc.nextInt();
//                    System.out.println("输入书籍名称：");
//                    String bookTitle = sc.next();
//                    System.out.println("输入价格：");
//                    double price = sc.nextDouble();
//                    System.out.println("输入作者：");
//                    String author = sc.next();
//                    s3.add_books(bookID, bookTitle, price, author);
//                    System.out.println();
//                    break;
//                case 5:
//                    StudentDAO s5 = new StudentDAO();
//                    System.out.println("输入出版社编号：");
//                    int pressID = sc.nextInt();
//                    System.out.println("输入出版社名称：");
//                    String pressTitle = sc.next();
//                    System.out.println("输入出版社地址：");
//                    String address = sc.next();
//                    System.out.println("输入出版社负责人：");
//                    String contactPerson = sc.next();
//                    System.out.println("输入出版社联系方式：");
//                    String telephone = sc.next();
//                    System.out.println("输入出版社邮箱地址：");
//                    String email = sc.next();
//
//                    s5.add_press(pressID, pressTitle, address, contactPerson, telephone, email);
//                    System.out.println();
//                    break;
//                case 6:
//                    StudentDAO s6 = new StudentDAO();
//                    System.out.println("输入配送公司编号：");
//                    int companyID = sc.nextInt();
//                    System.out.println("输入配送公司名称：");
//                    String companyTitle = sc.next();
//                    System.out.println("输入配送公司地址：");
//                    String companyAddress = sc.next();
//                    System.out.println("输入配送公司负责人：");
//                    String companyContactPerson = sc.next();
//                    System.out.println("输入配送公司联系方式：");
//                    String companyTelephone = sc.next();
//                    System.out.println("输入配送公司邮箱地址：");
//                    String companyEmail = sc.next();
//                    s6.add_company(companyID, companyTitle, companyAddress, companyContactPerson, companyTelephone, companyEmail);
//                    System.out.println();
//                    break;
//                case 7:
//                    StudentDAO s7 = new StudentDAO();
//                    System.out.println("输入删除的公司名称：");
//                    String companyTitle1 = sc.next();
//                    s7.delete_company(companyTitle1);
//                case 8:
//                    StudentDAO s8 = new StudentDAO();
//                    System.out.println("输入删除的书籍名称：");
//                    String bookTitle1 = sc.next();
//                    s8.delete_books(bookTitle1);
//                    break;
//                case 9:
//                    StudentDAO s9 = new StudentDAO();
//                    System.out.println("输入删除的出版社名称：");
//                    String pressTitle1 = sc.next();
//                    s9.delete_press(pressTitle1);
//                    break;
//                case 10:
//                    StudentDAO s10 = new StudentDAO();
//                    Books books1 = new Books();
//
//                    System.out.println("输入书名：");
//                    books1.setBookTitle(sc.next());
//                    System.out.println("输入修改后的价格：");
//                    books1.setPrice(sc.nextDouble());
//
//                    s10.update_books(books1);
//                    System.out.println();
//                    break;
//                case 11:
//                    StudentDAO s11 = new StudentDAO();
//                    Press press1 = new Press();
//
//                    System.out.println("输入出版社名称：");
//                    press1.setPressTitle(sc.next());
//                    System.out.println("输入修改后的地址：");
//                    press1.setAddress(sc.next());
//                    System.out.println("输入修改后的负责人：");
//                    press1.setContactPerson(sc.next());
//                    System.out.println("输入修改后的联系方式：");
//                    press1.setTelephone(sc.next());
//                    System.out.println("输入修改后的邮箱地址：");
//                    press1.setEmail(sc.next());
//
//                    s11.update_press(press1);
//                    System.out.println();
//                    break;
//                case 12:
//                    StudentDAO s12 = new StudentDAO();
//                    Company company1 = new Company();
//
//                    System.out.println("输入运输公司名称：");
//                    company1.setCompanyTitle(sc.next());
//                    System.out.println("输入修改后的地址：");
//                    company1.setAddress(sc.next());
//                    System.out.println("输入修改后的负责人：");
//                    company1.setContactPerson(sc.next());
//                    System.out.println("输入修改后的联系方式：");
//                    company1.setTelephone(sc.next());
//                    System.out.println("输入修改后的邮箱地址：");
//                    company1.setEmail(sc.next());
//
//                    s12.update_company(company1);
//                    System.out.println();
//                    break;


//                default:
//                    System.out.println("                    已退出，感谢您的使用                               ");
//                    System.exit(0);
//                    break;
            }
        }
    }
//        else if (choice == 2) {
//            String name = null;
//            String pass = null;
//            System.out.println("欢迎进入管理界面，请输入用户名和密码");
//            System.out.print("请输入您的用户名：");
//            name = sc.next();
//            System.out.print("请输入您的密码：");
//            pass = sc.next();
//            UseProperitesManageConfig Con_Sql1 = new UseProperitesManageConfig();
//            Con_Sql1.Sql_Link(name, pass, 0);
//
//            System.out.println("验证成功，你可进行以下操作");
//
//
//            while (true) {
//                System.out.println("1-查看重点客户");
//                System.out.println("2-更新餐桌状态");
//                System.out.println("3-查看所有员工信息");
//                System.out.println("4-查看员工个人工资信息");
//                System.out.println("5-退出");
//                System.out.print("请输入您的选择：");
//                int choice2 = sc.nextInt();
//                switch (choice2) {
//                    case 1:
//                        StudentDAO vip = new StudentDAO();
//                        //查询一个列表回来
//                        List<vip> list1 = vip.getAll_vip();
//                        for (vip stus1 : list1)
//                            System.out.println(stus1.getName() + " " + stus1.getPhone());
//                        System.out.println();
//                        break;
//                    case 2:
//                        StudentDAO s2 = new StudentDAO();
//                        Table Tab = new Table();
//
//                        System.out.println("输入餐桌号");
//                        Tab.setNumber(sc.nextInt());
//                        System.out.println("输入餐桌状态");
//                        Tab.setSta(sc.nextInt());
//
//                        s2.update_table(Tab);
//                        System.out.println();
//                        break;
//                    case 3:
//                        StudentDAO em = new StudentDAO();
//                        //查询一个列表回来
//                        List<Employee> list3 = em.getAll_Emp();
//                        for (Employee stus3 : list3)
//                            System.out.println(stus3.getId() + " " + stus3.getName() + " " + stus3.getSex() + " " + stus3.getAge() + " " + stus3.getSalary());
//                        System.out.println();
//                        break;
//
//                    case 4:
//                        StudentDAO em_salary = new StudentDAO();
//                        System.out.println("输入需要查询工资的员工姓名");
//                        String emname = sc.next();
//                        Employee stu2 = em_salary.em_salary(emname);
//                        System.out.println(stu2.getName() + " " + stu2.getSalary());
//                        break;
//
//                    default:
//                        System.out.println("                    已退出，感谢您的使用                               ");
//                        System.exit(0);
//
//                }
//            }
//
//        }
}
//}


